# 🚀 GTM Engineer Learning Journey

This repository documents my path to becoming a GTM Engineer.