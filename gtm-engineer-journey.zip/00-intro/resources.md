# Core Resources

- Obviously Awesome – April Dunford
- Hacking Growth – Sean Ellis